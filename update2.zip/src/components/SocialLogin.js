// import '../../node_modules/font-awesome/css/font-awesome.min.css';
import { FaFacebookSquare } from "react-icons/fa";
import { FaTwitterSquare } from "react-icons/fa";
import { FaGoogle } from "react-icons/fa";
import "../css/SocialLogin.css";
export default function SocialLogin() {
  return (
    <div className="container-sl">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"/>
        <div className="row">
          <div className="vl">
          </div>
        </div>
      <div className="col-sl">
        <a href="#" className="fb btn-sl">
          <i><FaFacebookSquare/></i> Login with Facebook
         </a>
        <a href="#" className="twitter btn-sl">
          <i><FaTwitterSquare/></i> Login with Twitter
        </a>
        <a href="#" className="google btn-sl">
          <i><FaGoogle/></i> Login with Google+
        </a>
      </div>
    </div>
  );
}
