import Book from "./book/Book";
import '../css/Pick.css';
import pickImage from './pickimg.jpg'
import { FaStar, FaRegStar } from "react-icons/fa";

export default function Pick({
    handleChange,
    handleReset,
    filterValues,
    filters,
    books,
    setFilters,
    getBooks,
    isAdmin,
    cartItemsNumber,
    setCartItemsNumber
}) {
    const item = books[0];
    return (
        <div className='pick-container'>
            <h5 className="pick-title">&#9830; Top Rate</h5>
            <div className="pick-content">
                <img className="pick-img" src={pickImage}/>
                <div className="pick-intro">
                    <h5>E-Commerce For Dummies</h5>
                    <p><i>"Easy to digest, Easy to read, Easy to get on."</i></p>
                    <div id="rating-pick">
                        <h5 className="d-flex align-items-center rating-pick">
                                        Rating:&nbsp;
                                        <FaStar
                                            className="star"
                                            key={1}
                                        />
                                        <FaRegStar
                                            className="star"
                                            key={5}
                                        />         
                            <a href='#'>&nbsp;55 Reviews</a>
                        </h5>
                    </div>
                </div>
            </div>
        </div>
    );
}