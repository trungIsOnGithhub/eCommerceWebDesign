import '../css/Banner.css';
export default function Banner() {
    return (
        <div className='banner-container'>
            <div id='banner1'> Advertisement 1</div>
            <div id='banner2'>
                <div id='banner2-1'> Advertisement 2</div>
                <div id='banner2-2'> Advertisement 3</div>
            </div>
        </div>
    );
}